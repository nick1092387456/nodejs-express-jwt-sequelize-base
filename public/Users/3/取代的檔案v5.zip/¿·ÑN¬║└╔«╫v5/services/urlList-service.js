const db = require('../models')
const { urlList } = db
const path = require('path')
const { execFile } = require('child_process')
const { checkQueryURL } = require('../tools/backendFormValidation')
const fetch = require('node-fetch')

const urlListServices = {
  checkState: async (req, res) => {
    try {
      const url = req.body.data
      const data = await urlList.findOne({ where: { originURL: url } })
      if (!!data && data.urlState === 'isValid') {
        res.status(400).json({ data: { link: data.shortURL } })
      } else {
        res.status(200).json({ data: { message: '未註冊' } })
      }
    } catch (err) {
      console.log(err)
    }
  },
  Search: async (req, res) => {
    try {
      const code = req.body.data //mda
      if (!checkQueryURL(code)) {
        res.status(400).json({ data: { message: '輸入內容有誤，請檢查' } })
      }
      const data = await urlList.findOne({ where: { shortURL: code } })
      if (data) {
        res.status(200).json({ data: { link: data.originURL } })
      } else {
        res.status(200).json({ data: { message: '網址失效或沒有申請' } })
      }
    } catch (err) {
      console.log(err)
    }
  },
  checkStatus: async (req, res) => {
    console.log('checkStatus start!!---------------------------------')
    try {
      const url = req.body.data
      const myPath = '/home/webroot/web_check.sh'
      execFile('echo', [myPath], { url }, (err, stdout, stderr) => {
        if (err) {
          console.log(err)
          return
        }
        console.log(`stdout: ${stdout}`)
        console.error(`stderr: ${stderr}`)
      })
    } catch (err) {
      console.log(err)
    }
  },
  googleCheck: async (req, res) => {
    const token = req.body.token // 從前端傳來的 token
    const ip = req.body.ip // 從前端傳來的 IP
    const uri = 'https://www.google.com/recaptcha/api/siteverify'
    // const data = {
    //   secret: '6LenPFUiAAAAAIGeeqbPeiSMbzMPmUukcd7uvDHt',
    //   response: token,
    //   remoteip: ip,
    // }
    const option = {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: `secret=6LenPFUiAAAAAIGeeqbPeiSMbzMPmUukcd7uvDHt&response=${token}&remoteip=${ip}`,
    }
    try {
      const response = await fetch(uri, option)
      const result = await response.json()
      console.log('後端result: ', result)
      if (result.success) {
        console.log('後端認證成功!')
        res.status(200).json({ result })
      } else {
        res.status(400).json({ response: '認證失敗' })
      }
    } catch (err) {
      console.log('googleFetch Error: ', err)
    }

    //   .then((res) => {
    //     //要做的事情
    //     return res.json()
    //   })
    //   .catch((e) => {
    //     console.log(e)
    //   })
    // res.status(200).json({ response })
    // console.log('RESPONSE: ', response)
  },
}

module.exports = urlListServices
