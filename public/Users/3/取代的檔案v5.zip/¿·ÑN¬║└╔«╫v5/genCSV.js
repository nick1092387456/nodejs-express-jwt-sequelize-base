const db = require('./models')
const { urlList } = db
const fs = require('fs')

async function genCSV() {
  try{
  let results = await urlList.findAll({ where: { urlState: 'isValid' } })
  results = results.map((result) => ({
    ...result.dataValues,
  }))
  const data = results.map((result) => {
    return `${result.shortURL},${result.originURL}`
  })
  let dataString = ''
  for (let i = 0; i < data.length; i++) {
    dataString += data[i] + '\n'
  }
  const mypath = __dirname + '/record_temp.csv'
  console.log(mypath) 
  await fs.writeFileSync(mypath, dataString)
  console.log('Done!')
  }catch(error){
   console.log(error)
  }
}

genCSV()


module.exports = { genCSV }
