const urlListServices = require('../services/urlList-service')

const urlListController = {
  checkState: (req, res) => {
    urlListServices.checkState(req, res)
  },
  checkStatus: (req, res) => {
    urlListServices.checkStatus(req, res)
  },
  Search: (req, res) => {
    urlListServices.Search(req, res)
  },
  googleCheck: (req, res) => {
    console.log(
      '---------------------googleCheckAccess-------------------------'
    )
    urlListServices.googleCheck(req, res)
  },
}

module.exports = urlListController
