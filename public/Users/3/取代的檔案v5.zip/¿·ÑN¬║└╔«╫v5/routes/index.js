const express = require('express')
const router = express.Router()
const nodemailer = require('nodemailer')
const { v4: uuidv4 } = require('uuid')
const { genShort } = require('../tools/shortenURL')
const { checkForm } = require('../tools/backendFormValidation')
const urlListController = require('../controllers/urlList-controller')
const db = require('../models')
const { urlList } = db
const { genCSV } = require('../genCSV')
const fetch = require('node-fetch')
const host = process.env.HOST
let mailOptions = null
let googleCheckOK = false

const smtpTransport = nodemailer.createTransport({
  host: process.env.EMAIL_HOST,
  // service: 'gmail',
  port: 25,
  secure: false,
  auth: {
    user: process.env.Mail_AC,
    pass: process.env.Mail_PS,
  },
})

router.post('/checkStatus', urlListController.checkStatus)
router.post('/checkState', urlListController.checkState)
router.post('/Search', urlListController.Search)
router.post('/googleCheck', async (req, res) => {
  const token = req.body.token // 從前端傳來的 token
  const ip = req.body.ip // 從前端傳來的 IP
  const uri = 'https://www.google.com/recaptcha/api/siteverify'
  const data = {
    secret: '6LenPFUiAAAAAIGeeqbPeiSMbzMPmUukcd7uvDHt',
    response: token,
    remoteip: ip,
  }
  const option = {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `secret=6LenPFUiAAAAAIGeeqbPeiSMbzMPmUukcd7uvDHt&response=${token}&remoteip=${ip}`,
  }
  try {
    const response = await fetch(uri, option)
    const result = await response.json()
    console.log('後端result: ', result)
    if (result.success) {
      googleCheckOK = true
      console.log('後端認證成功!')
      res.status(200).json({ result })
    } else {
      res.status(400).json({ response: '認證失敗' })
    }
  } catch (err) {
    console.log('googleFetch Error: ', err)
  }
})

router.post('/send', async (req, res) => {
  try {
    const { url, email } = req.body
    const checkFormResult = await checkForm(email, url, googleCheckOK)
    if (!checkFormResult) {
      // res.render('home', { message: '表單錯誤請重新填寫' })
      res.json({ data: { message: '驗證碼未驗證!' } })
      return
    }
    const verifyCode = uuidv4()
    const link = 'https://' + host + '/verify?id=' + verifyCode
    const srcLink = 'https://' + url
    const svcHost = process.env.HOST
    const hostLink = 'https://' + svcHost
    mailOptions = {
      from: 'GSN短網址服務 <turladmin@gsn.gov.tw>',
      to: email,
      bcc: 'Kae Hsu <Kae_Hsu@syscom.com.tw>, Nick Chuang <Nick_Chuang@syscom.com.tw>',
      subject: 'GSN短網址服務 - 短網址申請驗證信',
      text: `
        ${email} 您好：

        有人使用本電子郵件帳號進行短網址申請；該短網址申請之原始網址如下：
        ${srcLink}

        若您確認以上申請是您本人，請點擊以下連結完成申請驗證：
        ${link} 

        若您未使用GSN短網址服務或以上原始網址有誤，請直接忽略本通知，謝謝！

        GSN短網址服務
        (本郵件由系統自動發出，請勿回信)
            `,
    }
    const shortURL = await genShort()
    const data = await urlList.findOne({
      where: { originURL: 'https://' + url },
    })
    if (!data) {
      await urlList.create({
        shortURL,
        originURL: 'https://' + url,
        email,
        urlState: 'certificating',
        verifyCode: verifyCode,
      })
    } else {
      await data.update({
        ...data,
        shortURL,
        originURL: 'https://' + url,
        email,
        urlState: 'certificating',
        verifyCode: verifyCode,
      })
    }
    // googleCheckOK還原成False
    googleCheckOK = false
    smtpTransport.sendMail(mailOptions, function (error, response) {
      if (error) {
        console.log(error)
        res.end('error')
      } else {
        console.log('Message send: ' + response.message)
        res
          .status(200)
          .json({ data: { message: '確認信件已寄出，請檢查您的信箱' } })
      }
    })
  } catch (err) {
    console.log(err)
  }
})

router.get('/verify', async (req, res) => {
  try {
    if (true) {
      console.log('Domain is matched. Information is from Authentic email')
      const verifyCode = req.query.id
      const data = await urlList.findOne({ where: { verifyCode } })
      if (data) {
        console.log('email is verified')
        await data.update({
          ...data,
          urlState: 'isValid',
        })
        await genCSV()
        const shortURL = process.env.SHORT_HOST + data.shortURL
        const originURL = data.originURL
        res.render('result', { originURL, shortURL })
      } else {
        console.log('email is not verified')
        res.end('<h1>Bad Request</h1>')
      }
    } else {
      res.end('<h1>Request is from unknown source</h1>')
    }
  } catch (err) {
    console.log(err)
  }
})

router.get('/', (req, res) => {
  googleCheckOK = false
  res.render('home')
})

router.use((req, res) => {
  res.status(404)
  res.render('404')
})

module.exports = (app) => {
  app.use(router)
}
