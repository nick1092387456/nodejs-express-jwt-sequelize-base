(async () => {
  try {
	const result = await fetch('https://www.google.com')
	  console.log(result)
  }catch(err){
	console.log(err)
  }
})()
