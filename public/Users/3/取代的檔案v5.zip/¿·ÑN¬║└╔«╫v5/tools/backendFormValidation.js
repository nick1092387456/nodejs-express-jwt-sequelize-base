const db = require('../models')
const { urlList } = db

async function checkForm(email, url, googleCheckOK) {
  //失敗 return false
  const portURL = 'https://' + url
  const checkURLStateResult = await checkURLState(portURL)
  return !checkEmail(email) ||
    !checkURL(portURL) ||
    !checkURLStateResult ||
    !googleCheckOK
    ? false
    : true
}

function checkEmail(email) {
  let result = true
  const re = /.+@(?:[^.]+\.){0,}?gov\.tw$/
  const emailRule =
    /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z]+$/
  if (
    !email ||
    !emailRule.test(email) ||
    !re.test(email) ||
    email.length <= 8 ||
    email.length >= 64
  )
    result = false
  return result
}

function checkURL(url) {
  let result = true
  const re =
    /^(?:(https?\:\/\/)|)(?:([^\\\?\/\!\*\'\(\)\;\:\@\&\=\+\$\,\#\[\]]+\.)?gov\.tw)\b(?!\.)(?:\/|)(?!\/)(?:.*)/
  const URLRule =
    /[(http(s)?):\/\/(www\.)?a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&=]*)/
  if (
    !url ||
    !URLRule.test(url) ||
    !re.test(url) ||
    url.length < 10 ||
    url.length >= 2048
  )
    result = false
  url = url.replace(/^(http(s)?\:\/\/)|(\/)$/gm, '')
  return result
}

function checkQueryURL(url) {
  let result = false
  const URLRule = /[a-km-zA-HJ-NP-Z1-9]/
  if (!url) {
    return result
  }
  if (!URLRule.test(url)) {
    return result
  }
  if (url.length === 23) {
    queryURLElement.value = url.replace(/^https:\/\/turl.gov.tw\//, '')
    url = queryURLElement.value
  }
  if (url.length !== 3) {
    return result
  }
  result = true
  return result
}

async function checkURLState(url) {
  //藉由返回false表示驗證失敗
  const data = await urlList.findOne({ where: { originURL: url } })
  return data && data.urlState === 'isValid' ? false : true
}

module.exports = {
  checkEmail,
  checkURL,
  checkForm,
  checkQueryURL,
}
