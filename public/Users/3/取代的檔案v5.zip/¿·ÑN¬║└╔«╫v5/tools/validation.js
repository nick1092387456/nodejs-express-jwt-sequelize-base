const urlCheckBtn = document.getElementById('checkBtn')
const queryURLSearchBtn = document.getElementById('searchBtn')
const submitButton = document.getElementById('submitButton')
let checkStatus = false

//google機器人區--------------------------------------------
// GAS 部署為網路應用程式後取得的 URL
const uriGAS =
  'https://script.google.com/macros/s/AKfycbwv7IPphpV5nGMlqezv3VRr3nciP5xThkrVJjPPEMCwe8SufeLOGdSP3lIcBvvON2bchg/exec'
const uriIP = 'https://www.cloudflare.com/cdn-cgi/trace'

var onloadCallback = () => {
  grecaptcha.render('googleRobot', {
    sitekey: '6LenPFUiAAAAAI5UhA1fzo-F5F1iSqSoXln5gPNI',
    theme: 'light',
    size: 'normal',
    callback: verifyCallback,
    'expired-callback': expired,
    'error-callback': error,
  })
}

async function verifyCallback(token) {
  try {
    const myHost = window.location.origin
    const googleCheckURL = myHost + '/googleCheck'
    const ipResponse = await fetch(uriIP)
    const ipResult = await ipResponse.text()
    const resultArr = ipResult.split('\n')
    let ip = ''
    for (let i = 0, len = resultArr.length; i < len; i++) {
      const tempArr = resultArr[i].split('=')
      if (tempArr[0] === 'ip') {
        ip = tempArr[1]
        break
      }
    }
    const checkResponse = await fetch(googleCheckURL, {
      method: 'POST',
      body: JSON.stringify({ token: token, ip: ip }),
      headers: { 'Content-Type': 'application/json' },
    })
    if (checkResponse.ok) {
      const { response } = await checkResponse.json()
      console.log('前端Result', response.success)
      window.alert('驗證成功')
    } else {
      window.alert(checkResponse['error-codes'][0])
    }
  } catch (err) {
    window.alert(err)
  }
}

// 過期要做的事
function expired(ex) {
  window.alert('reCAPTCHA 驗證程序到期')
}

// 失敗要做的事
function error(err) {
  window.alert('reCAPTCHA 驗證失敗')
}

//form驗證區---------------------------------------------
;(function validate_submit() {
  'use strict'
  const forms = document.querySelectorAll('.needs-validation')
  const urlElement = document.getElementById('url')
  const emailElement = document.getElementById('email')
  Array.from(forms).forEach((form) => {
    form.addEventListener(
      'submit',
      async (event) => {
        if (checkSubmit() === false) {
          event.preventDefault()
          event.stopPropagation()
          const checkURLStateResult = await checkURLState(urlElement)
          if (checkURLStateResult) {
            urlElement.classList.add('is-invalid')
            urlElement.classList.remove('is-valid')
            setErrorFor(
              urlElement,
              '此原始網址已完成短網址申請；對應短網址如下：'
            )
          }
        }
        event.preventDefault()
        event.stopPropagation()
        const response = await fetch('/send', {
          method: 'POST',
          body: JSON.stringify({
            url: urlElement.value,
            email: emailElement.value,
          }),
          headers: { 'Content-Type': 'application/json' },
        })
        if (response.ok) {
          const { data } = await response.json()
          setReplyMessage('sendResponse', data.message)
          urlElement.classList.remove('is-valid')
          emailElement.classList.remove('is-valid')
          urlElement.value = ''
          urlElement.readOnly = false
          emailElement.value = ''
        }
      },
      false
    )
  })
})()
;(function validate_url() {
  const urlElement = document.getElementById('url')
  urlElement.addEventListener('input', (e) => {
    checkStatus = false
    setReplyMessage('sendResponse', '')
    if (checkURL(urlElement) === false) {
      urlElement.classList.add('is-invalid')
      urlElement.classList.remove('is-valid')
      urlCheckBtn.classList.add('btn-outline-secondary')
      urlCheckBtn.classList.remove('btn-primary')
      setLinkMessage('replyMessage', '')
      urlCheckBtn.disabled = true
    } else {
      urlCheckBtn.disabled = false
      setErrorFor(urlElement, '請點擊右側"檢測"按鈕完成檢測')
      urlCheckBtn.classList.remove('btn-outline-secondary')
      urlCheckBtn.classList.add('btn-primary')
    }
  })
})()
;(function validate_queryURL() {
  const queryURLElement = document.getElementById('queryURL')
  queryURLElement.addEventListener('input', (e) => {
    if (checkQueryURL(queryURLElement) === false) {
      queryURLElement.classList.add('is-invalid')
      queryURLElement.classList.remove('is-valid')
      queryURLSearchBtn.classList.add('btn-outline-secondary')
      queryURLSearchBtn.classList.remove('btn-primary')
      setLinkMessage('queryMessage', '')
      queryURLSearchBtn.disabled = true
    } else {
      queryURLSearchBtn.disabled = false
      queryURLSearchBtn.classList.remove('btn-outline-secondary')
      queryURLSearchBtn.classList.add('btn-primary')
      queryURLElement.classList.remove('is-invalid')
      queryURLElement.classList.add('is-valid')
    }
  })
})()
;(function validate_email() {
  const emailElement = document.getElementById('email')
  emailElement.addEventListener('input', (e) => {
    setReplyMessage('sendResponse', '')
    if (checkEmail(emailElement) === false) {
      emailElement.classList.add('is-invalid')
      emailElement.classList.remove('is-valid')
    } else {
      emailElement.classList.remove('is-invalid')
      emailElement.classList.add('is-valid')
    }
  })
})()
;(async function validateURLClick() {
  try {
    const urlCheckResultModal = new bootstrap.Modal(
      document.getElementById('urlCheckResultModal'),
      {}
    )
    urlCheckBtn.addEventListener('click', async (e) => {
      const urlElement = document.getElementById('url')
      const shortURL = await checkURLState(urlElement)
      //const fetchURL = await checkURLStatus(urlElement)
      if (shortURL) {
        e.preventDefault
        // setModalInput(shortURL)
        setLinkMessage('replyMessage', shortURL)
        setErrorFor(urlElement, '此原始網址已完成短網址申請；對應短網址如下：')
        urlElement.classList.add('is-invalid')
        urlElement.classList.remove('is-valid')
        // urlCheckResultModal.show()
      } else {
        urlElement.classList.remove('is-invalid')
        urlElement.classList.add('is-valid')
        urlElement.readOnly = true
        urlCheckBtn.disabled = true
        checkStatus = true
      }

      //if(!fetchURL) {
      //e.preventDefault
      //setErrorFor(urlElement, '網頁無效')
      //urlElement.classList.add('is-invalid')
      //urlElement.classList.remove('is-valid')
      //}
      //if(fetchURL && !shortURL){
      //checkStatus = true
      //	urlElement.readOnly = true
      //	urlCheckBtn.disabled = true
      //      urlElement.classList.remove('is-invalid')
      //	urlElement.classList.add('is-valid')
      //      }
    })
  } catch (err) {
    console.log(err)
  }
})()
;(async function validateQueryURLClick() {
  try {
    const urlCheckResultModal = new bootstrap.Modal(
      document.getElementById('urlCheckResultModal'),
      {}
    )
    queryURLSearchBtn.addEventListener('click', async (e) => {
      const queryURLElement = document.getElementById('queryURL')
      const originURL = await checkQueryURLState(queryURLElement)
      if (originURL) {
        e.preventDefault
        //setModalInput(shortURL)
        setLinkMessage('queryMessage', originURL)
        //urlCheckResultModal.show()
      } else {
        setErrorFor(queryURLElement, '原網址查詢不到')
        queryURLElement.classList.add('is-invalid')
        queryURLElement.classList.remove('is-valid')
      }
      //if(!fetchURL) {
      //e.preventDefault
      //setErrorFor(urlElement, '網頁無效')
      //urlElement.classList.add('is-invalid')
      //urlElement.classList.remove('is-valid')
      //}
      //if(fetchURL && !shortURL){
      //checkStatus = true
      //	urlElement.readOnly = true
      //	urlCheckBtn.disabled = true
      //      urlElement.classList.remove('is-invalid')
      //	urlElement.classList.add('is-valid')
      //      }
    })
  } catch (err) {
    console.log(err)
  }
})()

function checkSubmit() {
  const urlElement = document.getElementById('url')
  const emailElement = document.getElementById('email')
  let result = true
  //驗證網址
  if (checkURL(urlElement) === false) {
    urlElement.classList.add('is-invalid')
    urlElement.classList.remove('is-valid')
    result = false
  } else {
    urlElement.classList.remove('is-invalid')
    urlElement.classList.add('is-valid')
  }

  //驗證Email
  if (checkEmail(emailElement) === false) {
    emailElement.classList.add('is-invalid')
    emailElement.classList.remove('is-valid')
    result = false
  } else {
    emailElement.classList.remove('is-invalid')
    emailElement.classList.add('is-valid')
  }

  //驗證檢測按鈕是否檢測

  if (checkStatus === false) result = false
  return result
}
function checkURL(urlElement) {
  let result = false
  const url = urlElement.value
  const re =
    /^(?:(https?\:\/\/)|)(?:([^\\\?\/\!\*\'\(\)\;\:\@\&\=\+\$\,\#\[\]]+\.)?gov\.tw)\b(?!\.)(?:\/|)(?!\/)(?:.*)/
  const URLRule =
    /^(?:(https?\:\/\/)|)(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&=]*)/
  if (!url) {
    setErrorFor(urlElement, '長網址欄位不可為空白')
    return result
  }
  if (!URLRule.test(url)) {
    setErrorFor(urlElement, '網址格式不正確')
    return result
  }
  if (!re.test(url)) {
    setErrorFor(urlElement, "僅接受'gov.tw'的網域做轉址")
    return result
  }
  if (url.length <= 10) {
    setErrorFor(urlElement, '網址太短')
    return result
  }
  if (url.length >= 2048) {
    setErrorFor(urlElement, '網址過長')
    return result
  }
  urlElement.value = url.replace(/^(http(s)?\:\/\/)|(\/)$/gm, '')
  result = true
  return result
}
function checkEmail(emailElement) {
  let result = false
  const email = emailElement.value
  const re = /.+@(?:[^.]+\.){0,}?gov\.tw$/
  const emailRule =
    /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z]+$/
  if (!email) {
    setErrorFor(emailElement, '信箱欄位不可空白')
    return result
  }
  if (!emailRule.test(email)) {
    setErrorFor(emailElement, '信箱格式不正確')
    return result
  }
  if (!re.test(email)) {
    setErrorFor(emailElement, '只接受 *.gov.tw 信箱人員申請')
    return result
  }
  if (email.length <= 8) {
    setErrorFor(emailElement, '信箱過短')
    return result
  }
  if (email.length >= 64) {
    setErrorFor(emailElement, '信箱過長')
    return result
  }
  result = true
  return result
}
function checkQueryURL(queryURLElement) {
  let result = false
  let url = queryURLElement.value
  const URLRule = /[a-km-zA-HJ-NP-Z1-9]/
  if (!url) {
    setErrorFor(queryURLElement, '欄位不可為空白')
    return result
  }
  if (!URLRule.test(url)) {
    setErrorFor(
      queryURLElement,
      //'短網址不正確，請排除小寫L、大寫i、大寫O、數字0'
      '含短網址未用字元；請排除數字０、英文字母小寫ｌ、大寫Ｉ、大寫Ｏ'
    )
    return result
  }
  if (url.length === 23) {
    queryURLElement.value = url.replace(/^https:\/\/turl.gov.tw\//, '')
    url = queryURLElement.value
  }
  if (url.length !== 3) {
    setErrorFor(queryURLElement, '短網址為三個字元')
    return result
  }

  result = true
  return result
}

function setErrorFor(selectedElement, message) {
  const formControl = selectedElement.parentElement
  const messageBox = formControl.querySelector('.invalid-feedback')
  messageBox.innerText = message
}

async function checkURLStatus(urlElement) {
  try {
    const myHost = window.location.origin
    const checkStatusRoute = myHost + '/checkStatus'
    const response = await fetch(checkStatusRoute, {
      method: 'POST',
      body: JSON.stringify({ data: 'https://' + urlElement.value }),
      headers: { 'Content-Type': 'application/json' },
    })
    console.log(
      'checkURLStatus validatiy response!!----------------' + response.ok
    )
    if (response.ok) {
      return true
    }
    return false
  } catch (err) {
    console.log(err)
  }
}
async function checkURLState(urlElement) {
  try {
    const myHost = window.location.origin
    const turlHost = 'https://gov.tw'
    const checkState = myHost + '/checkState'
    const response = await fetch(checkState, {
      method: 'POST',
      body: JSON.stringify({ data: 'https://' + urlElement.value }),
      headers: { 'Content-Type': 'application/json' },
    })
    if (!response.ok) {
      const { data } = await response.json()
      const shortURL = turlHost + '/' + data.link
      return shortURL
    }
    return false
  } catch (err) {
    console.log(err)
  }
}

async function checkQueryURLState(queryURLElement) {
  try {
    const myHost = window.location.origin
    const searchURL = myHost + '/Search'
    const response = await fetch(searchURL, {
      method: 'POST',
      body: JSON.stringify({ data: queryURLElement.value }),
      headers: { 'Content-Type': 'application/json' },
    })
    if (response.ok) {
      const { data } = await response.json()
      const originURL = data.link
      return originURL
    }
    return false
  } catch (err) {
    console.log(err)
  }
}

// function setModalInput(content) {
//   const modalBody = document.getElementById('shortIsExistModalContent')
//   modalBody.innerHTML = `<p>${content}</p>`
// }

function setLinkMessage(elementId, content) {
  const replyMessage = document.getElementById(elementId)
  replyMessage.innerHTML = `<a href="${content}">${content}</a> `
}

function setReplyMessage(elementId, content) {
  const replyMessage = document.getElementById(elementId)
  replyMessage.innerHTML = content
}

function clipboard() {
  // Get the text field
  var copyText = document.getElementById('myInput')

  // Select the text field
  copyText.select()
  copyText.setSelectionRange(0, 99999) // For mobile devices

  // Copy the text inside the text field
  navigator.clipboard.writeText(copyText.value)

  // Alert the copied text
  alert('Copied the text: ' + copyText.value)
}

//nav script
const triggerTabList = [].slice.call(
  document.querySelectorAll('#bologna-list a')
)
triggerTabList.forEach(function (triggerEl) {
  const tabTrigger = new bootstrap.Tab(triggerEl)

  triggerEl.addEventListener('click', function (event) {
    event.preventDefault()
    tabTrigger.show()
  })
})
